import { HttpClient, HttpEvent, HttpHandler, HttpHeaders, HttpInterceptor, HttpRequest } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { JwtResponseI} from "../auth/jwt_response";
import { LoginI} from "../login/login";
import { SignNewUser} from "../signNewUser/signNewUser";

/**
 * Se establece esta clase como proveedor para establecerse como dependencia 
 */
@Injectable({
    providedIn: "root"
  })

export class UsersService implements HttpInterceptor{  
    /**
     * Se declara una constante de tipo String para almacenar la raíz de los distintos endpoints definidos
     */
     AUTH_SERVER: string = 'http://51.38.51.187:5050/api/v1';

    sigNewUser: SignNewUser={
        email:"",
        password:"",
        name:"",
        surname:"",
        id:""
    }

    loginI: LoginI={
        email:"",
        password:""
    }

    headers: { headers: any; };
    token: string | undefined;
    
    constructor(private http: HttpClient){
        this.headers = {
            headers: new HttpHeaders({
              'Content-Type': 'application/json',
              Accept: 'application/json'
            })
          };
    }

    /**
     * Permite interceptar las peticiones para añadir modificaciones 
     * @param req 
     * @param next 
     * @returns 
     */
    intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        let authReq = req;
        const token = this.getTokenCadena();
        if (!token) {
            return next.handle(authReq);
        }

        const request = req.clone({
            headers: req.headers.append('Authorization', `Bearer ${token}`)
        });
        
        return next.handle(request);
    }

    /**
     * Función que envía por POST los datos del usuario a registrar
     * @param sigNewUser 
     * @returns 
     */
    registerUser(sigNewUser: SignNewUser){
        return this.http.post<JwtResponseI>(this.AUTH_SERVER + '/users/',
        {name: sigNewUser.name, 
        surname:sigNewUser.surname, 
        email: sigNewUser.email, 
        password:sigNewUser.password}, this.headers);
    }

    /**
     * Función que permite el login del usuario en el servidor una vez este se ha registrado
     * @param loginI Variable de tipo LoginI, para el envío de email y password para el login del usuario
     * @returns 
     */
    loginUser(loginI: LoginI): Observable<JwtResponseI>{
        
        return this.http.post<JwtResponseI>(this.AUTH_SERVER + '/auth/log-in/',
        {email: loginI.email, 
        password:loginI.password}, this.headers);         
    }

    /**
     * Función que permite verificar si el usuario ya se encuentra logueado contra el servidor, para compararlo con el almacenado en el objeto Storage local del navegador
     * @returns 
     */
     signUser(sigNewUser: SignNewUser): Observable<JwtResponseI>{  
        console.log(sigNewUser.name);     
        return this.http.post<JwtResponseI>(this.AUTH_SERVER + '/auth/sign-up/',
        {name: sigNewUser.name, 
        surname:sigNewUser.surname, 
        email: sigNewUser.email, 
        password:sigNewUser.password}, this.headers);         
    }

    /**
     * Función que borra token de usuario logueado
     */
    logoutUser(): void{
        this.token = '';
        localStorage.removeItem("token");
        sessionStorage.removeItem("token");
    }

    getListUsers(): Observable<JwtResponseI>{
        return this.http.get<JwtResponseI>(this.AUTH_SERVER + '/users/', this.headers);
    }

    /**
     * Función que guarda el token a nivel local
     * @param token Parametro que se almacena a nivel local del navegador
     */
    saveToken(token: string): void{
        localStorage.setItem("token",token);
        sessionStorage.setItem("token",token);
    }

    /**
     * 
     * @returns Devuelve un valor booleano si el token está almacenado para usuario ya logueado
     */
    public getToken(): boolean{
        return (localStorage.getItem('token') !== null);
    }

    /**
     * 
     * @returns Devuelve un valor booleano si el token está almacenado para usuario ya logueado
     */
    public getTokenCadena(): any{
        return localStorage.getItem('token');
    }

    /**
     * Función para realizar un timeout para espera a la respuesta del servidor con el listado de usuarios
     * @param ms 
     * @returns 
     */
     async delay(ms: number) {
        return new Promise( resolve => setTimeout(resolve, ms) );
    }

}

