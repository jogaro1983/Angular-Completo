import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TareasComponent } from './tarealogin.component';
import { SignupComponent } from './tareasignup.component';
import { TareasLogoutComponent } from './tarealogout.component';
import { TareasListUsersComponent } from './tarealistusers.component';

/**
 * Se definen las rutas de la aplicación para acceso a los 4 componente definidos: login, registro, página de usuario y listado de usuarios registrados
 */
const routes: Routes = [
  {path:'login', component:TareasComponent},
  {path:'sign', component: SignupComponent},
  {path:'logout', component: TareasLogoutComponent},
  {path:'listUsers', component: TareasListUsersComponent}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
