import { Component, OnInit } from '@angular/core';
import { UsersService } from '../tareas/tareas.service';
import { JwtResponseI } from './jwt_response';

@Component({
  selector: 'tarealistusers',
  templateUrl: './tarealistusers.component.html'
})
export class TareasListUsersComponent {
  public users: any;
  public state: any;
  constructor(private tareasService: UsersService){
  }
    /**
     * Función a la que se llama nada más acceder a esta sección para cargar el listado de usuarios registrados
     */
    ngOnInit() { 
      this.getListUsers();
    }
    /**
     * Se obtiene listado de usuarios ya registrados, en el que se utilza el método suscribe de tipo Observable, para la transmisión de forma síncrona o asíncrona de una fuente de datos. Se realiza un delay de 2 segundos para que se carguen los datos de la petición
     */
    getListUsers(): void{
      this.users="Cargando datos....";
      this.tareasService.delay(2000);
        this.tareasService.getListUsers().subscribe(
          result=>{
            this.users = result;
          },
          error=>{
            this.state = <any>error;
          }  
        );  
    };
}