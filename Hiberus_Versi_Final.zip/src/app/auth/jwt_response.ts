export interface JwtResponseI{
    dataUser:{
        name: string,
        surname: string,
        email: string,
        password: string,
        accessToken: string,
        expiresIn: string
    }
}