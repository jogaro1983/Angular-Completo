export interface LoginI{
    email: string,
    password: string
}