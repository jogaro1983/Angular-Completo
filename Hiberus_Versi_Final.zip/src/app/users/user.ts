export interface UserI{
    email: string,
    password: string,
    name: string,
    surname: string,
    id: string
}