import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AuthRoutingModule } from './auth.routing.module';
import { HttpClientModule } from "@angular/common/http";
import { TareasComponent } from './tarealogin.component';
import { TareasLogoutComponent } from './tarealogout.component';
import { FormsModule } from '@angular/forms';
import { UsersService } from '../tareas/tareas.service';
import { SignupComponent } from './tareasignup.component';
import { TareasListUsersComponent } from './tarealistusers.component';

@NgModule({
  declarations: [
    TareasComponent,
    TareasLogoutComponent,
    SignupComponent,
    TareasListUsersComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    AuthRoutingModule,
    HttpClientModule
  ],
  providers: [UsersService]
})
export class AuthModule { }
