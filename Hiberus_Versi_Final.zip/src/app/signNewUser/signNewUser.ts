export interface SignNewUser{
    email: string,
    password: string,
    name: string,
    surname: string,
    id: string
}