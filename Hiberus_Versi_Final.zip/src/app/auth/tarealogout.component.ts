import { Component } from '@angular/core';
import { UsersService } from '../tareas/tareas.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Observable, Subscription } from 'rxjs';
import { JwtResponseI } from './jwt_response';
import { LoginI } from '../login/login';
import { SignNewUser } from '../signNewUser/signNewUser';

@Component({
  selector: 'tarealogout',
  templateUrl: './tarealogout.component.html'
})

export class TareasLogoutComponent {
  email: any;
  errorLogin: string="";
  tokenLogin: Subscription | undefined;
  tokenState: boolean = false;
  signupUser: Observable<JwtResponseI> | undefined;
  errorState: any;
  
  sigNewUser: SignNewUser={
    email:"",
    password:"",
    name:"",
    surname:"",
    id:""
  }

  constructor(private tareasService: UsersService, private routeInfo: ActivatedRoute, private router: Router){
  }
  
  /**
   * Se comprueba si el usuario ya se encuentra logueado al verificar el token almacenado. 
   * Si el usuario está logueado, se mostrará información del email con el que se ha 
   * iniciado sesión. En caso de que se navegue a la pantalla de inicio o de registro, y se desee volver a acceder
   * a la pantalla de información de usuario, se controlará que este ya se encuentre logueado, para mostrar un 
   * mensaje acorde a dicha lógica.
   */
  ngOnInit() {    
      this.email = this.routeInfo.snapshot.queryParamMap.get('email');
      this.tokenLogin = this.signUpComponent();
      this.tokenState = this.tareasService.getToken();
      console.log("Token recuperado: " + this.tokenLogin + "; Token almacenado: " + this.tareasService.getTokenCadena());
      if (this.tokenState == true && this.email === null && this.tokenLogin === this.tareasService.getTokenCadena()){
        this.email = "Sesión ya iniciada";
        this.errorLogin="";
      } 
  }
  /**
   * Permite realizar POST para obtener token de endpoint
   * @returns 
   */
  signUpComponent(){
    return this.tareasService.signUser(this.sigNewUser).subscribe(
      (result: any)=>{
        console.log("TOKEN: " + result["accessToken"]);
        this.signupUser = result["accessToken"];       
      },
      error=>{
        console.log("Error: " + <string>error);
        this.errorLogin = <any>error;
      }  
    );
  }
  

  /**
   * Función que permite limpiar objeto Storage del navegador con el token almacenado
   */
  onLogout(): void{
      this.tareasService.logoutUser();
      this.router.navigateByUrl('/login');
      };
}