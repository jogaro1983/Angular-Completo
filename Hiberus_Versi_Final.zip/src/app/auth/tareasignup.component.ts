import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators} from '@angular/forms';
import { SignNewUser } from '../signNewUser/signNewUser';
import { UsersService } from '../tareas/tareas.service';

@Component({
  selector: 'tareasignup',
  templateUrl: './tareasignup.component.html',
  providers: [UsersService]
})



export class SignupComponent implements OnInit{
  public user: any;
  public state: any;

  sigNewUser: SignNewUser={
    email:"",
    password:"",
    name:"",
    surname:"",
    id:""
  }

  ngForm: FormGroup;
  /**
   * Validaciones de formularios reactivos
   * @param tareasService 
   * @param fb 
   */
    constructor(private tareasService: UsersService, public fb: FormBuilder){
      this.ngForm = this.fb.group({
        name: ['', [Validators.required]],
        surname:['', [Validators.required]],
        email: ['', [Validators.required],
        [Validators.pattern("[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,}$")]],
        password:['', [Validators.required],
        [Validators.pattern("(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}")]]
      });
    }
  
  
    ngOnInit() {
    }

    /**
     * Se devuelve la respuesta tras registrar un usuario 
     */
    onSignUp(){
        this.tareasService.registerUser(this.sigNewUser).subscribe(         
          result=>{
            console.log(result);
              this.user = result;
              this.state = "";
              /**
               * Con la siguiente línea podríamos acceder a la página de Login una vez registrado al usuario*/
              //this.router.navigateByUrl('/login');
            },
          error=>{
              this.state = <any>error;
              this.user = "";
            }               
        );
      }
}