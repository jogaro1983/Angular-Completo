/**
 * Componente para la verificación de que el usuario
 * está dado de alta en el sistema y permita acceder a la zona habilitada para ello
 */
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { LoginI } from '../login/login';
import { UsersService } from '../tareas/tareas.service';


@Component({
  selector: 'tarealogin',
  templateUrl: './tarealogin.component.html'
})

export class TareasComponent{
  public user: any;
  public state: any;

  login: LoginI={
    email:"",
    password:""
  }

  ngForm: FormGroup;
  /**
   * Se declara a nivel de constructor un FormBuilder para la posterior validación de 
   * campos de entrada del formulario, en ese caso se establecen los dos campos como requeridos, 
   * además de incluir otra validación para que cumplan un 
   * determinado patrón para la anotación del formato de email o password permitidos.
   * @param tareasService 
   * @param router 
   * @param fb 
   */
  constructor(private tareasService: UsersService, public fb: FormBuilder){
    this.ngForm = this.fb.group({
      email: 
      ['', 
        [Validators.required]
      ],
      password:
      ['', 
        [Validators.required]
      ]
    });
  }


  ngOnInit() {
    
  }

  /**
   * Función para el envío del formulario para el login, junto con el almacenamiento del token creado.
   */
  onLogin(){
    this.tareasService.loginUser(this.login).subscribe(
      (result: any)=>{
        this.tareasService.saveToken(result["accessToken"]);
        console.log(this.tareasService.getToken());
        this.user = result; 
        this.state="";       
      },
      error=>{
        this.state = <any>error;
        this.user = "";
      }  
    );
  }

}